class Questoes {
  final String imagem;
  final String titulo;
  final String alternativa1;
  final String alternativa2;
  final String alternativa3;
  final String alternativa4;
  final String alternativa5;

  Questoes({
    required this.imagem,
    required this.titulo,
    required this.alternativa1,
    required this.alternativa2,
    required this.alternativa3,
    required this.alternativa4,
    required this.alternativa5,
  });
}