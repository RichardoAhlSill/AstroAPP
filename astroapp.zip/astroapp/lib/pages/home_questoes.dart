import 'package:flutter/material.dart';
import '../domain/questoes.dart';
import '../widget/lista_questoes_card.dart';

class HomeQuestoes extends StatefulWidget {

  const HomeQuestoes({Key? key}) : super(key: key);

  @override
  _HomeQuestoesState createState() => _HomeQuestoesState();
}

class _HomeQuestoesState extends State<HomeQuestoes> {
  Questoes questao1 = Questoes(
    imagem:
    'https://upload.wikimedia.org/wikipedia/commons/thumb/3/3c/Size_planets_comparison.jpg/1280px-Size_planets_comparison.jpg',
    titulo: 'Vivemos no planeta Terra. Além dele, existem outros sete girando em torno do Sol, cujos nomes esperamos que já saiba. Então, responda: '
        'Quantos planetas têm somente 5 letras em seu nome? Assinale a única alternativa correta.',
    alternativa1: 'a) 4',
    alternativa2: 'b) 0',
    alternativa3: 'c) 1',
    alternativa4: 'd) 2',
    alternativa5: 'e) 3',
  );
  Questoes questao2 = Questoes(
    imagem:
    'https://upload.wikimedia.org/wikipedia/commons/thumb/3/3c/Size_planets_comparison.jpg/1280px-Size_planets_comparison.jpg',
    titulo: 'Vivemos no planeta Terra. Além dele, existem outros sete girando em torno do Sol, cujos nomes esperamos que já saiba. Então, responda: '
        'Quantos planetas têm somente 5 letras em seu nome? Assinale a única alternativa correta.',
    alternativa1: 'a) 4',
    alternativa2: 'b) 0',
    alternativa3: 'c) 1',
    alternativa4: 'd) 2',
    alternativa5: 'e) 3',
  );
  Questoes questao3 = Questoes(
    imagem:
    'https://upload.wikimedia.org/wikipedia/commons/thumb/3/3c/Size_planets_comparison.jpg/1280px-Size_planets_comparison.jpg',
    titulo: 'Vivemos no planeta Terra. Além dele, existem outros sete girando em torno do Sol, cujos nomes esperamos que já saiba. Então, responda: '
        'Quantos planetas têm somente 5 letras em seu nome? Assinale a única alternativa correta.',
    alternativa1: 'a) 4',
    alternativa2: 'b) 0',
    alternativa3: 'c) 1',
    alternativa4: 'd) 2',
    alternativa5: 'e) 3',
  );
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: false,
        backgroundColor: Color.fromARGB(255, 18, 30, 138),
        title: const Text(
          'AstroAPP',
          style: TextStyle(fontSize: 24),
        ),
      ),
      backgroundColor: Colors.grey[100],
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            const SizedBox(height: 16),
            CardQuestoes(questoes: questao1),
            CardQuestoes(questoes: questao2),
            CardQuestoes(questoes: questao3),
          ],
        ),
      ),
    );
  }
}